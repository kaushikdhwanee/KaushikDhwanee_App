



<script type="text/javascript" src="js/widgets.min.js"></script>

<script type="text/javascript" src="js/globalize.js"></script>

<script type="text/javascript" src="js/jqueryui_forms.js"></script>

			<div class="content-wrapper">

     			<div class="row">

					<div class="col-lg-9">



						<div class="panel panel-flat">

							<div class="panel-heading">

								<h5 class="panel-title">Add Admin</h5>

								<br>



							</div>



							<div class="col-md-12 product">

							

							  <div class="form-group  col-md-4">



								 <input class="form-control" placeholder="Admin Name" type="text">



								</div>

                                 <div class="form-group1  col-md-4">

										<input type="file" class="file-styled">

								</div>

								<div class="form-group  col-md-4">

								 <input class="form-control" placeholder="Mobile No" type="text">

								</div>

								

								<div class="form-group  col-md-4">

								 <input class="form-control" placeholder="Email ID" type="text">

								</div>

								 <div class="form-group  col-md-4">

	

									<div class="input-group">

										<span class="input-group-addon"><i class="icon-calendar"></i></span>

										<input type="text" class="form-control datepicker" placeholder="Date of Birth">

									</div>

							

								</div>

								<div class="form-group  col-md-4">

								                   <select data-placeholder="Select Type" class="select">

						                            	 <option value="Cambodia">Select Type</option> 

						                                <option value="Cambodia">Master Admin</option> 

						                                <option value="Cameroon">Branch Admin</option> 

						                               

						                            </select>

								</div>

								<div class="form-group  col-md-12">

								 <textarea rows="2" cols="5" class="form-control" placeholder="Address"></textarea>

								</div>

								<div class="clearfix"></div>

								<div class="sub-btn form-group">

		<button type="button" class="btn btn-primary active legitRipple center">SUBMIT</button>

		</div>

							</div>

							

							<div class="clearfix"></div>

						</div>

						



					</div>



					<div class="col-lg-3">



				

					</div>

				</div>

			</div>

			<!-- /main content -->



		</div>

		

	</div>



	<!-- Footer -->



	

</body>

</html>

