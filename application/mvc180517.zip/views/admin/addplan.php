<?php
//print_r($classes);exit;
?>
			<div class="content-wrapper">

     			<div class="row">

					<div class="col-lg-9">



						<div class="panel panel-flat">

							<div class="panel-heading">

								<h5 class="panel-title">Creat Plan</h5>

								<br>



							</div>

							<form id="plan" method="post" action="<?=base_url("admin/insertplan")?>">

							<div class="col-md-12 product">

								<div class="form-group col-md-6">
									
									<div class="multi-select-full">
									  
										 <select data-placeholder="Select Branch" id="branch_id" name="branch_id" class="select">

						                            	<option value="">Select</option>

						                            	<?php
						                            	if(!empty($branches))
						                            	{
						                            		foreach ($branches as $branch_info) {
						                            			?>
						                            			 <option value="<?=$branch_info['id']?>"><?=$branch_info['branch_name']?></option> 
						                            	<?php	}
						                            	}
						                            	?>

						                                

						                 </select>
										
									</div>
								</div>
							

							  	<div class="form-group  col-md-6">

								                   <select  data-placeholder="Select Class" name="class_id"  id="class_id" class="select">

						                            	 	<option value="">Select class</option>

						                                <?php
						                            	if(!empty($classes))
						                            	{
						                            		foreach ($classes as $cat_info) {
						                            			?>
						                            			 <option value="<?=$cat_info['id']?>"><?=$cat_info['class_name']?></option> 
						                            	<?php	}
						                            	}
						                            	?>

						                            </select>

								</div>

                                
								<div class="form-group  col-md-6">
								<label>1 session in per week</label>
								 <input class="form-control" name="one_session"  onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?=@$plan_info['one_session']?>" placeholder="Price per Month" type="text">

								</div>

								<div class="form-group  col-md-6">
								<label>2 session in per week</label>

								 <input class="form-control" name="two_session"  onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?=@$plan_info['two_session']?>" placeholder="Price per Month" type="text">

								</div>

								<div class="form-group  col-md-6">
								<label>3 session in per week</label>

								 <input class="form-control" name="three_session"  onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?=@$plan_info['three_session']?>" placeholder="Price per Month" type="text">

								</div>

								<div class="form-group  col-md-6">

								<label>4 session in per week</label>

								 <input class="form-control" name="four_session"  onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?=@$plan_info['four_session']?>" placeholder="Price per Month" type="text">

								</div>

								<div class="form-group  col-md-6">

								<label>5 session in per week</label>

								 <input class="form-control" name="five_session"  onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?=@$plan_info['five_session']?>" placeholder="Price per Month" type="text">

								</div>

								<div class="form-group  col-md-6">

								<label>6 session in per week</label>

								 <input class="form-control" name="six_session"  onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?=@$plan_info['six_session']?>" placeholder="Price per Month" type="text">

								</div>

								 <div class="clearfix"></div>

								<div class="sub-btn form-group">
				<input type="hidden" name="id" id="plan_id" value="">
		<button type="submit" class="btn btn-primary active legitRipple center">SUBMIT</button>

		</div>

							</div>

							</form>

							<div class="clearfix"></div>

						</div>

						



					</div>



					<div class="col-lg-3">



				<?php //include_once 'includes/right-sidepanel.php'?>

					</div>

				</div>

			</div>

			<!-- /main content -->



		</div>

		

	</div>



	<!-- Footer -->


	

</body>

</html>

<script type="text/javascript">
  $(document).ready(function(){
  	
    $("#plan").validate({
      rules: {
        class_id: "required",
        branch_id:"required",
        one_session:"required",
        two_session:"required",
        three_session: "required",
        four_session: "required",
        five_session: "required",
        six_session: "required",

      },
    });
   
  

  		$("#class_id").change(function(){
		  
		   	var class_id = $(this).val();
		   	var branch_id = $("#branch_id").val();

		   	$("input[name=one_session]").val('');
			$("input[name=two_session]").val('');
			$("input[name=three_session]").val('');
			$("input[name=four_session]").val('');
			$("input[name=five_session]").val('');
			$("input[name=six_session]").val('');
			$("input[name=id]").val('');
		   	
		   	//alert(branch_id);alert(class_id);
		   	if(class_id !="" && branch_id !="")
		   	{
		   		$.ajax({
		   		type:"post",
		   		url:"<?=base_url('admin/getplanbybranch')?>",
		   		data:{class_id:class_id,branch_id:branch_id},
		   		success: function(message){
		   			var resp = JSON.parse(message);
		   			if(resp.success==1)
		   			{
		   				$("input[name=one_session]").val(resp.one_session);
		   				$("input[name=two_session]").val(resp.two_session);
		   				$("input[name=three_session]").val(resp.three_session);
		   				$("input[name=four_session]").val(resp.four_session);
		   				$("input[name=five_session]").val(resp.five_session);
		   				$("input[name=six_session]").val(resp.six_session);
		   				$("input[name=id]").val(resp.id);

		   			}

		   		}
		   	});
		   	}
		   	
   		}); 

});
</script>