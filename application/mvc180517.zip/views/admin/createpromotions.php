<?php //include_once 'includes/header.php'?>
<div class="content-wrapper">
   <div class="row">
      <div class="col-lg-9">
     	<div class="panel panel-flat">
							<div class="panel-heading">
								<h5 class="panel-title">Creat Promotions</h5>
							</div>

							<div class="col-md-12 product">
							
							  <div class="col-md-8 col-md-offset-2">
							     <div class="form-group">
									<label class="control-label col-lg-6"><p class="sib-dis">Sibling Discounts</p></label>
									<div class="col-lg-6">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="Sibling Discounts">
											<span class="input-group-addon">%</span>
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
								 <div class="form-group">
									<label class="control-label col-lg-6"><p class="sib-dis">3 Months Upfront Discounts</p></label>
									<div class="col-lg-6">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="3 Months Upfront Discounts">
											<span class="input-group-addon">%</span>
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
								 <div class="form-group">
									<label class="control-label col-lg-6"><p class="sib-dis">6 Months Upfront Discounts</p></label>
									<div class="col-lg-6">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="6 Months Upfront Discounts">
											<span class="input-group-addon">%</span>
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
									 <div class="form-group">
									<label class="control-label col-lg-6"><p class="sib-dis">12 Months Upfront Discounts</p></label>
									<div class="col-lg-6">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="12 Months Upfront Discounts">
											<span class="input-group-addon">%</span>
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
								 <div class="form-group">
									<label class="control-label col-lg-6"><p class="sib-dis">Referal </p></label>
									<div class="col-lg-6">
										
											<input type="text" class="form-control" placeholder="Referal">
									
									</div>
									<div class="clearfix"></div>
								</div>
								 <div class="form-group">
									<label class="control-label col-lg-6"><p class="sib-dis">Referee</p></label>
									<div class="col-lg-6">
										
											<input type="text" class="form-control" placeholder="Referee">
											
									
									</div>
									<div class="clearfix"></div>
								</div>
								<div class="clearfix"></div>
								<div class="sub-btn form-group">
		<button type="button" class="btn btn-primary active legitRipple center">SUBMIT</button>
		</div>
							</div>
							</div>
							<div class="clearfix"></div>
						</div>
						</div>
      <div class="col-lg-3">
         <?php //include_once 'includes/right-sidepanel.php'?>
      </div>
   </div>
</div>
<!-- /main content -->
</div>
</div>
<!-- Footer -->
<?php //include_once 'includes/footer.php'?>

</body>
</html>

