<div id="modal_h2 " class="modal fade modal_h2 editbatch"></div>

							<div class="panel panel-white weekdays" data-id="1">

						<div class="panel-heading" data-toggle="collapse" data-target="#collapsible-control-right-group1">

									<h6 class="panel-title">

										<a>Monday</a>

									</h6>

								</div>

								<div id="collapsible-control-right-group1" class="panel-collapse collapse in">

									<div class="panel-body1">

										  <div class="col-md-12 padding-tps">

			<form method="post" id="form1">

				       <div class="col-md-3" >

                  <div class="form-group">

                     <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="start_time" placeholder="Start Time">

                     </div>

                  </div>



                  </div>

               </div>

			    <div class="col-md-3" >

                  <div class="form-group">

                                       <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="end_time" placeholder="End Time">

                     </div>

                  </div>

                  </div>

               </div>

			   	  <div class="col-md-4" >

                    

									

									<div class="multi-select-full" id="teacher1">

									  

										<select class="multiselect" name="teachers[]" multiple="multiple" >

                                  
                              <?php if(!empty($teachers)){
                                 foreach ($teachers as $teacher_info) {?>
                                 <option value="<?=$teacher_info['teacher_id']?>"><?=$teacher_info['teacher_name']?></option>
                              <?php }
                                 }?>

										</select>



										

									</div>

							

               </div>

			    <div class="col-md-2" >

                  <div class="form-group">
                  <!-- <input type="hidden" name="type" value="1"> -->
                  
                  <button type="button" data-id="1" class="btn btn-primary active legitRipple center savebatch">SUBMIT</button>

                  </div>

               </div>

				   </form>

				    <div class="clear"></div>

				  </div>

               

					<table class="table text-nowrap" id="getclasses1" ></table>

            

									</div>

								</div>

							</div>

                             <div class="panel panel-white weekdays" data-id="2">

						<div class="panel-heading" data-toggle="collapse" data-target="#collapsible-control-right-group2">

									<h6 class="panel-title">

										<a>Tuesday</a>

									</h6>

								</div>

								<div id="collapsible-control-right-group2" class="panel-collapse collapse ">

									<div class="panel-body1">

										  <div class="col-md-12 padding-tps">

         <form method="post" id="form2">

                   <div class="col-md-3" >

                  <div class="form-group">

                     <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="start_time" placeholder="Start Time">

                     </div>

                  </div>



                  </div>

               </div>

             <div class="col-md-3" >

                  <div class="form-group">

                                       <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="end_time" placeholder="End Time">

                     </div>

                  </div>

                  </div>

               </div>

                 <div class="col-md-4" >

                    

                           

                           <div class="multi-select-full" id="teacher1">

                             

                              <select class="multiselect" name="teachers[]" multiple="multiple" >

                                  
                              <?php if(!empty($teachers)){
                                 foreach ($teachers as $teacher_info) {?>
                                 <option value="<?=$teacher_info['teacher_id']?>"><?=$teacher_info['teacher_name']?></option>
                              <?php }
                                 }?>

                              </select>



                              

                           </div>

                     

               </div>

             <div class="col-md-2" >

                  <div class="form-group">
                  <!-- <input type="hidden" name="type" value="1"> -->
                  
                  <button type="button" data-id="2" class="btn btn-primary active legitRipple center savebatch">SUBMIT</button>

                  </div>

               </div>

               </form>

                <div class="clear"></div>

              </div>

               

										         <table class="table text-nowrap" id="getclasses2"></table>

            

									</div>

								</div>

							</div>

						       <div class="panel panel-white weekdays" data-id="3">

						<div class="panel-heading" data-toggle="collapse" data-target="#collapsible-control-right-group3">

									<h6 class="panel-title">

										<a>Wednesday</a>

									</h6>

								</div>

								<div id="collapsible-control-right-group3" class="panel-collapse collapse ">

									<div class="panel-body1">

										  <div class="col-md-12 padding-tps">

         <form method="post" id="form3">

                   <div class="col-md-3" >

                  <div class="form-group">

                     <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="start_time" placeholder="Start Time">

                     </div>

                  </div>



                  </div>

               </div>

             <div class="col-md-3" >

                  <div class="form-group">

                                       <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="end_time" placeholder="End Time">

                     </div>

                  </div>

                  </div>

               </div>

                 <div class="col-md-4" >

                    

                           

                           <div class="multi-select-full" id="teacher1">

                             

                              <select class="multiselect" name="teachers[]" multiple="multiple" >

                                  
                              <?php if(!empty($teachers)){
                                 foreach ($teachers as $teacher_info) {?>
                                 <option value="<?=$teacher_info['teacher_id']?>"><?=$teacher_info['teacher_name']?></option>
                              <?php }
                                 }?>

                              </select>



                              

                           </div>

                     

               </div>

             <div class="col-md-2" >

                  <div class="form-group">
                  <!-- <input type="hidden" name="type" value="1"> -->
                  
                  <button type="button" data-id="3" class="btn btn-primary active legitRipple center savebatch">SUBMIT</button>

                  </div>

               </div>

               </form>

                <div class="clear"></div>

              </div>

               

										         <table class="table text-nowrap" id="getclasses3"></table>

            

									</div>

								</div>

							</div>

						      

							   <div class="panel panel-white weekdays" data-id="4">

						<div class="panel-heading" data-toggle="collapse" data-target="#collapsible-control-right-group4">

									<h6 class="panel-title">

										<a>Thursday</a>

									</h6>

								</div>

								<div id="collapsible-control-right-group4" class="panel-collapse collapse">

									<div class="panel-body1">

										  <div class="col-md-12 padding-tps">

         <form method="post" id="form4">

                   <div class="col-md-3" >

                  <div class="form-group">

                     <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="start_time" placeholder="Start Time">

                     </div>

                  </div>



                  </div>

               </div>

             <div class="col-md-3" >

                  <div class="form-group">

                                       <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="end_time" placeholder="End Time">

                     </div>

                  </div>

                  </div>

               </div>

                 <div class="col-md-4" >

                    

                           

                           <div class="multi-select-full" id="teacher1">

                             

                              <select class="multiselect" name="teachers[]" multiple="multiple" >

                                  
                              <?php if(!empty($teachers)){
                                 foreach ($teachers as $teacher_info) {?>
                                 <option value="<?=$teacher_info['teacher_id']?>"><?=$teacher_info['teacher_name']?></option>
                              <?php }
                                 }?>

                              </select>



                              

                           </div>

                     

               </div>

             <div class="col-md-2" >

                  <div class="form-group">
                  <!-- <input type="hidden" name="type" value="1"> -->
                  
                  <button type="button" data-id="4" class="btn btn-primary active legitRipple center savebatch">SUBMIT</button>

                  </div>

               </div>

               </form>

                <div class="clear"></div>

              </div>

               

										         <table class="table text-nowrap" id="getclasses4"></table>

            

									</div>

								</div>

							</div>

						

							  <div class="panel panel-white weekdays" data-id="5">

						<div class="panel-heading" data-toggle="collapse" data-target="#collapsible-control-right-group5">

									<h6 class="panel-title">

										<a>Friday</a>

									</h6>

								</div>

								<div id="collapsible-control-right-group5" class="panel-collapse collapse ">

									<div class="panel-body1">

										  <div class="col-md-12 padding-tps">

         <form method="post" id="form5">

                   <div class="col-md-3" >

                  <div class="form-group">

                     <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="start_time" placeholder="Start Time">

                     </div>

                  </div>



                  </div>

               </div>

             <div class="col-md-3" >

                  <div class="form-group">

                                       <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="end_time" placeholder="End Time">

                     </div>

                  </div>

                  </div>

               </div>

                 <div class="col-md-4" >

                    

                           

                           <div class="multi-select-full" id="teacher1">

                             

                              <select class="multiselect" name="teachers[]" multiple="multiple" >

                                  
                              <?php if(!empty($teachers)){
                                 foreach ($teachers as $teacher_info) {?>
                                 <option value="<?=$teacher_info['teacher_id']?>"><?=$teacher_info['teacher_name']?></option>
                              <?php }
                                 }?>

                              </select>



                              

                           </div>

                     

               </div>

             <div class="col-md-2" >

                  <div class="form-group">
                  <!-- <input type="hidden" name="type" value="1"> -->
                  
                  <button type="button" data-id="5" class="btn btn-primary active legitRipple center savebatch">SUBMIT</button>

                  </div>

               </div>

               </form>

                <div class="clear"></div>

              </div>

               

										         <table class="table text-nowrap" id="getclasses5"></table>

            

									</div>

								</div>

							</div>

						

						  <div class="panel panel-white weekdays" data-id="6">

						<div class="panel-heading" data-toggle="collapse" data-target="#collapsible-control-right-group6">

									<h6 class="panel-title">

										<a>Saturday</a>

									</h6>

								</div>

								<div id="collapsible-control-right-group6" class="panel-collapse collapse ">

									<div class="panel-body1">

										  <div class="col-md-12 padding-tps">

         <form method="post" id="form6">

                   <div class="col-md-3" >

                  <div class="form-group">

                     <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="start_time" placeholder="Start Time">

                     </div>

                  </div>



                  </div>

               </div>

             <div class="col-md-3" >

                  <div class="form-group">

                                       <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="end_time" placeholder="End Time">

                     </div>

                  </div>

                  </div>

               </div>

                 <div class="col-md-4" >

                    

                           

                           <div class="multi-select-full" id="teacher1">

                             

                              <select class="multiselect" name="teachers[]" multiple="multiple" >

                                  
                              <?php if(!empty($teachers)){
                                 foreach ($teachers as $teacher_info) {?>
                                 <option value="<?=$teacher_info['teacher_id']?>"><?=$teacher_info['teacher_name']?></option>
                              <?php }
                                 }?>

                              </select>



                              

                           </div>

                     

               </div>

             <div class="col-md-2" >

                  <div class="form-group">
                  <!-- <input type="hidden" name="type" value="1"> -->
                  
                  <button type="button" data-id="6" class="btn btn-primary active legitRipple center savebatch">SUBMIT</button>

                  </div>

               </div>

               </form>

                <div class="clear"></div>

              </div>

               

										         <table class="table text-nowrap" id="getclasses6"></table>

            

									</div>

								</div>

							</div>

						

						<div class="panel panel-white weekdays" data-id="7">

						<div class="panel-heading" data-toggle="collapse" data-target="#collapsible-control-right-group7">

									<h6 class="panel-title">

										<a>Sunday</a>

									</h6>

								</div>

								<div id="collapsible-control-right-group7" class="panel-collapse collapse ">

									<div class="panel-body1">

										  <div class="col-md-12 padding-tps">

         <form method="post" id="form7">

                   <div class="col-md-3" >

                  <div class="form-group">

                     <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="start_time" placeholder="Start Time">

                     </div>

                  </div>



                  </div>

               </div>

             <div class="col-md-3" >

                  <div class="form-group">

                                       <div class="time-div">

                     <div class="input-group">

                        <span class="input-group-addon"><i class="icon-alarm"></i></span>

                        <input type="text" class="form-control pickatime" name="end_time" placeholder="End Time">

                     </div>

                  </div>

                  </div>

               </div>

                 <div class="col-md-4" >

                    

                           

                           <div class="multi-select-full" id="teacher1">

                             

                              <select class="multiselect" name="teachers[]" multiple="multiple" >

                                  
                              <?php if(!empty($teachers)){
                                 foreach ($teachers as $teacher_info) {?>
                                 <option value="<?=$teacher_info['teacher_id']?>"><?=$teacher_info['teacher_name']?></option>
                              <?php }
                                 }?>

                              </select>



                              

                           </div>

                     

               </div>

             <div class="col-md-2" >

                  <div class="form-group">
                  <!-- <input type="hidden" name="type" value="1"> -->
                  
                  <button type="button" data-id="7" class="btn btn-primary active legitRipple center savebatch">SUBMIT</button>

                  </div>

               </div>

               </form>

                <div class="clear"></div>

              </div>

               

				<table class="table text-nowrap" id="getclasses7"></table>

            

									</div>

								</div>

							</div>

					
<script type="text/javascript">
var batch_id = "<?=$batch_id?>";
var  day_type=1;
$(document).ready(function(){

 function getbatchclasses()
 {
   $.ajax({
      type:"post",
      data:{day_type:day_type,batch_id:batch_id},
      url:"<?=base_url("admin/getbatchclasses")?>",
      success : function(data){
         $("#getclasses"+day_type).html(data);
         $('.dropdown-toggle').dropdown();
      }
   });
 }
 getbatchclasses();
   $(".weekdays").click(function(){

   day_type = $(this).data('id');
   getbatchclasses();

 });
   $(".savebatch").click(function(){
      type = $(this).data('id');
      var data = $("#form"+type).serialize();

   $.ajax({
      type:"post",
      url:"<?=base_url("admin/insertbatch")?>",
      data:data+"&class_id="+class_id+"&branch_id="+branch_id+"&type="+type+"&batch_id="+batch_id,
      success: function(data){
         alert("thank u");
         $("#form"+type)[0].reset();

      }
   });

   });

      $(document).on("click",".editbatchclass",function(){
         
            var batch_class_id = $(this).data('id');
            $.ajax({

               type:"post",
               
               url:"<?=base_url("admin/editbatchclass")?>",
               data:{batch_class_id:batch_class_id},
               success: function(data){
                     
                     $(".editbatch").html(data);
                     $(".editbatch").find(".multiselect").multiselect('refresh');
                     $('.modal_h2').modal('show'); //$('#multibox').multiselect();
                    // $(".multiselect").multiselect('refresh');
                    // $(".select").selectpicker("refresh");
                     }

            });

      });



      $(document).on("click",".updatestatus1",function(){
        
            var batch_class_id = $(this).attr('id');
            var status = $(this).data('id');
            
            $.ajax({
               type:"post",
               url:"<?=base_url('admin/updatebatchclassstatus')?>",
               data:{batch_class_id:batch_class_id,status:status},
               success: function(data)
               {
                 //
                 if(data==1)
                 {
                   alert("status updated successfully");  
                 }                  
               }

            });

      });

      $(document).on("click","#updatebatchclass",function(){

         //type = $(this).data('id');
         var data = $("#editformz").serialize();

         $.ajax({
            type:"post",
            url:"<?=base_url("admin/updatebatch")?>",
            data:data+"&batch_id="+batch_id,
            success: function(data){
               $('.modal_h2').modal('hide');
               getbatchclasses();
               alert("Batch Updated successfully");

               
            }
         });

   });

});

</script>				

						