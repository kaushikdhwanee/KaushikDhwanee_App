<div class="content-wrapper">
   <div class="row">
      <div class="col-lg-9">
     	<div class="panel panel-flat">
							<div class="panel-heading">
								<h5 class="panel-title">Enroll Students</h5>
								
							</div>
							<form method="post" action="<?=base_url("admin/insertenrollstudent")?>" id="enrollstudent">
							<div class="col-md-12 product">

								 <div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Branch Name</p></label>
									  <div class="form-group  col-md-4">
	
									    <?=$user_info['branch_name']?>
							
								</div>

									<div class="clearfix"></div>
								</div>

							     <div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Student Name</p></label>
									  <div class="form-group  col-md-4">
	
									    <?=$user_info['name']?><!-- (<?=@$registration_amount?>) -->
							
								</div>

									<div class="clearfix"></div>
								</div>
								  <div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Select Class</p></label>
									 <div class="form-group  col-md-4">
	
									  <select  class="select" name="class_id" id="class_id">
						                    <option value=""> Select class</option>

			                               <?php
			                            	if(!empty($classes))
			                            	{
			                            		foreach ($classes as $cat_info) 
			                            		{
			                            			?>
			                            			 <option value="<?=$cat_info['id']?>"><?=$cat_info['class_name']?></option> 
			                            	<?php	}
			                            	}
			                            	?>
						                </select>
							
								</div>

									<div class="clearfix"></div>
								</div> 
								
								 <div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Select Plan</p></label>
									 <div class="form-group  col-md-4">
	
									    <select data-placeholder="Select Category" class="select " id="plan_id" name="plan_id">

						                            	<option value="">Select Plan</option>
														
						                                
						                            </select>
							
								</div>
								<label class="control-label col-lg-4"><p class="sib-dis"> <span id="sessions_per_week"></span> Classes A Week</p></label>
									<div class="clearfix"></div>
								</div>
								 <div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Select Date</p></label>
								<div class="form-group  col-md-4">
									<div class="input-group">
										<span class="input-group-addon"><i class="icon-calendar"></i></span>
										<input type="text" class="form-control" id="datepicker2" class="datepicker1" name="start_date" placeholder="Select Date">
									</div>
								</div>
								 
									<div class="clearfix"></div>
								</div>
								<div class="selectdays"></div>
								
								<div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Current Month Amount </p></label>
									<div class="col-lg-4">
										<div class="input-group">
											<span class="input-group-btn">	
												<button class="btn btn-default btn-icon legitRipple" type="button">Rs</button>
											</span>
											<input type="text" class="form-control" id="current_month_amount" name="current_month_amount" value="" placeholder="Amount">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>

								 

								<div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Select Next month plan</p></label>
									 <div class="form-group  col-md-4">
	
									  <select  class="select" name="next_plan" id="next_plan">
						                 <option value="">Select</option>
	                        			 <option value="1|0">1 month (0%)</option> 
	                        			 <option value="3|<?=$discount_info['three_months_discount']?>">3 Months (<?=$discount_info['three_months_discount']?>%)</option> 
	                        			 <option value="6|<?=$discount_info['six_months_discount']?>">6 Months (<?=$discount_info['six_months_discount']?>%)</option> 
	                        			 <option value="12|<?=$discount_info['one_year_discount']?>">1 Year (<?=$discount_info['one_year_discount']?>%)</option> 
	                        			 <!-- <option value="<?=$discount_info['id']?>"><?=$discount_info['class_name']?></option>  -->

			                            	
						                </select>
							
								</div>

								<label class="control-label col-lg-4"><p class="sib-dis" id="next_plan_amount">Select Next month plan</p></label>

									<div class="clearfix"></div>
								</div> 
								<?php if(!empty($registration_amount)){?>
								<div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Registration Amount </p></label>
									<div class="col-lg-4">
										<div class="input-group">
											<span class="input-group-btn">	
												<button class="btn btn-default btn-icon legitRipple" type="button">Rs</button>
											</span>
											<input type="text" class="form-control" id="" name="registration_amount" value="<?=@$registration_amount?>" placeholder="Amount">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>

								<?php }?>

								<div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Amount To Be Paid </p></label>
									<div class="col-lg-4">
										<div class="input-group">
											<span class="input-group-btn">	
												<button class="btn btn-default btn-icon legitRipple" type="button">Rs</button>
											</span>
											<input type="text" class="form-control" id="total_amount" name="total_amount" value="<?=@$registration_amount?>" placeholder="Amount">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>

								<div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Admin Discount %<input type="text" class="form-control col-md-4" id="admin_discount" name="admin_discount"  onkeypress="return event.charCode>=48 && event.charCode<=57"  placeholder="Discount"></p></label>
									<div class="col-lg-4">
										<div class="input-group">
											<span class="input-group-btn">	
												<button class="btn btn-default btn-icon legitRipple" type="button">Rs</button>
											</span>
											<input type="text" class="form-control" id="admin_discount_amount"  readonly   placeholder="Discount">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>

								<div class="form-group">
									<label class="control-label col-lg-4"><p class="sib-dis">Final Amount To Be Paid </p></label>
									<div class="col-lg-4">
										<div class="input-group">
											<span class="input-group-btn">	
												<button class="btn btn-default btn-icon legitRipple" type="button">Rs</button>
											</span>
											<input type="text" class="form-control" id="final_amount" name="final_amount" value="<?=@$registration_amount?>" placeholder="Amount">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>


									
								<div class="clearfix"></div>
								<div class="sub-btn form-group">
								<input type="hidden" name="branch_id" id="branch_id" value="<?=$user_info['branch_id']?>">
								<input type="hidden" name="user_id" id="user_id" value="<?=$user_info['id']?>">
								<input type="hidden" name="member_id" id="" value="<?=$user_id?>">
								<input type="hidden" name="sibling_discount" id="sibling_discount">

								<input type="hidden" name="next_month_amount" id="next_month_amount" >

					<button type="submit" class="btn btn-primary active legitRipple center">Pay Now</button>
		</div>
						
							</div>
							</form>
							<div class="clearfix"></div>
						</div>
						</div>
      <div class="col-lg-3">
      </div>
   </div>
</div>
<!-- /main content -->
</div>
</div>
<!-- Footer -->

</body>
</html>

<script type="text/javascript">
var total_amount;
var sibling_discount = 0;
var registration_amount  = "<?=$registration_amount==null?0:$registration_amount?>";
var current_month_amount;
var current_month_amount_discount=0;
var price_per_month;
var discount_persent;
var final_amount;
var feature_months_amount =0;
var member_id = "<?=$user_id?>";
//var currnt_month_sessions;
var sessions_per_week;
var price_per_session;
function fomartTimeShow(time24){
var tmpArr = time24.split(':'), time12;
if(+tmpArr[0] == 12) {
time12 = tmpArr[0] + ':' + tmpArr[1] + ' pm';
} else {
if(+tmpArr[0] == 00) {
time12 = '12:' + tmpArr[1] + ' am';
} else {
if(+tmpArr[0] > 12) {
time12 = (+tmpArr[0]-12) + ':' + tmpArr[1] + ' pm';
} else {
time12 = (+tmpArr[0]) + ':' + tmpArr[1] + ' am';
}
}
}
return time12;
}
	$(document).ready(function(){
		   $("#class_id").change(function(){

		   	$('#plan_id').empty();
		   	$('#plan_id').append('<option value="">Select Plan</option>');
		   	var class_id = $(this).val();
		   	var branch_id = $("#branch_id").val();
		   	if(class_id!="" && branch_id!="")
		   	{
		   		$.ajax({
			   		type:"post",
			   		url:"<?=base_url('admin_services/getplans')?>",
			   		data:{class_id:class_id,branch_id:branch_id},
			   		success: function(message){
			   			var resp = JSON.parse(message);
			   			if(resp.success==1)
			   			{
			   				
			   					  $('#plan_id').append('<option value="1|'+resp.one_session+'"> 1 Session for Week '+resp.one_session+'</option>');
			   					  $('#plan_id').append('<option value="2|'+resp.two_session+'"> 2 Session for Week '+resp.two_session+'</option>');
			   					  $('#plan_id').append('<option value="3|'+resp.three_session+'"> 3 Session for Week  '+resp.three_session+'</option>');
			   					  $('#plan_id').append('<option value="4|'+resp.four_session+'"> 4 Session for Week '+resp.four_session+'</option>');
			   					  $('#plan_id').append('<option value="5|'+resp.five_session+'"> 5 Session for Week '+resp.five_session+'</option>');
			   					  $('#plan_id').append('<option value="6|'+resp.six_session+'"> 6 Session for Week '+resp.six_session+'</option>');
			   					  $(".select").selectpicker("refresh");

			   				

			   			}

			   		}
			   	});
		   	}else{
		   		alert('please select required fields');
		   	}

   		}); 

		   $("#plan_id").change(function(){

		   	var class_id = $("#class_id").val();
		   	var branch_id = $("#branch_id").val();
		   	var user_id =$("#user_id").val();

		   	var str = $(this).val();
		   	var str1 = str.split("|");	
		   	sessions_per_week = str1[0];
		   	price_per_month = str1[1];
		   	price_per_session = price_per_month/(sessions_per_week*4);

		   	$.ajax({
		   		type:"post",
		   		url:"<?=base_url('admin_services/getplan')?>",
		   		data:{sessions_per_week:sessions_per_week,class_id:class_id,branch_id:branch_id,user_id:user_id},
		   		success: function(message){
		   			var resp = JSON.parse(message);
		   			if(resp.success==1)
		   			{
		   				sibling_discount = resp.sibling_discount;
		   				price_per_month = price_per_month-(price_per_month*sibling_discount/100);
		   				price_per_session = price_per_month/(sessions_per_week*4);

		   				$("#sessions_per_week").text(sessions_per_week);
		   				$(".selectdays").html(resp.weekdays);
		   				$(".select").selectpicker("refresh");
		   				current_month_amount = 0;
						total_amount =0;
						feature_months_amount =0;
						$("#total_amount").val(total_amount);
						$("#final_amount").val(total_amount);
						$("#current_month_amount").val(current_month_amount);
						$("#sibling_discount").val(sibling_discount);
						$("#next_plan_amount").html(''); 
						$("#next_plan").val('').trigger('change');
						$(".select").selectpicker("refresh");
						

		   			}

		   		}
		   	});
   		}); 

		 $(document).on('change',".selectday",function(){
		 	
		 	var id = $(this).attr('data');
		 	var class_id = $("#class_id").val();
			var branch_id = $("#branch_id").val();
			var start_date = $("#datepicker2").val();
			//alert(start_date);
		 	if(id!=undefined && start_date !="")
		 	{//alert("hiiiiiiii");
			 	$('#week'+id).empty();
			   	$('#week'+id).append('<option value="">Select batch</option>');
			   	
			   	
			   	var weekday = $(this).val();

			   	var selected_days = [];

			   	$(".selectday").each(function(){
			   		selected_days.push($(this).val());
			   	});

			   	
			   	$.ajax({
			   		type:"post",
			   		url:"<?=base_url('admin/getbatchclassesbyweekday')?>",
			   		data:{weekday:weekday,class_id:class_id,branch_id:branch_id,start_date:start_date,selected_days:selected_days},
			   		success: function(message){
			   			var resp = JSON.parse(message);
			   			if(resp.success==1)
			   			{
			   				var i=1;
			   				current_month_amount = parseInt(price_per_session)*parseInt(resp.no_days);
			   				//alert(resp.no_days);
			   				$("#current_month_amount").val(current_month_amount);
			   				total_amount = parseInt(registration_amount)+parseInt(current_month_amount);
			   				$("#total_amount").val(total_amount);
			   				$("#final_amount").val(total_amount);

			   				$.each(resp.batches, function(index,value){
			   					//console.log(value.start_time);
			   					$("#week"+id).append('<option value="'+value.id+'">Batch'+i+'('+fomartTimeShow(value.start_time)+'-'+fomartTimeShow(value.end_time)+')</option>');
			   					i++;
			   				});
			   				$(".select").selectpicker("refresh");
			   				
			   			}

			   		}
			   	});
		   }
   		});   

		$(document).on('change',"#datepicker2",function(){
		 	//alert("fffffffffff");
			var start_date = $(this).val();
			//alert(start_date);
		 	if(start_date !="")
		 	{
			   	var selected_days = [];

			   	$(".selectday").each(function(){
			   		selected_days.push($(this).val());
			   	});

			   	
			   	$.ajax({
			   		type:"post",
			   		url:"<?=base_url('admin/getweekdayscount')?>",
			   		data:{selected_days:selected_days,start_date:start_date},
			   		success: function(message){
			   			var resp = JSON.parse(message);
			   			if(resp.success==1)
			   			{
			   				current_month_amount = parseInt(price_per_session)*parseInt(resp.no_days);
			   				$("#current_month_amount").val(current_month_amount);
			   				total_amount = parseInt(registration_amount)+parseInt(current_month_amount);
			   				$("#total_amount").val(total_amount);
			   				$("#final_amount").val(total_amount);
			   				
			   			}

			   		}
			   	});
		   }
   		});


		$("#next_plan").change(function(){
			feature_months_amount = 0;
			current_month_amount_discount =0;
			//admin_discount =
			var str = $(this).val();
			if(str!="")
			{
				var str1 = str.split("|");	
			   	var months = str1[0];
			   	var discount = str1[1];
			   	/*if(discount!=null)
			   	{*/
			   		current_month_amount_discount = current_month_amount*(discount/100);
			   		abcd = current_month_amount-current_month_amount_discount;
			   		$("#current_month_amount").val(abcd);
			   	/*}*/

			   	feature_months_amount = (parseInt(price_per_month)*parseInt(months))-((parseInt(price_per_month)*parseInt(months))*(parseInt(discount)/100));
			   	total_amount1 = parseInt(registration_amount)+parseInt(current_month_amount)-parseInt(current_month_amount_discount)+parseInt(feature_months_amount);
				$("#total_amount").val(total_amount1);
				$("#final_amount").val(total_amount1);

			   	$("#next_plan_amount").text(feature_months_amount); 
			   	$("#next_month_amount").val(feature_months_amount); 
			   	$("#admin_discount").val('');
			   	$("#admin_discount_amount").val('');
			}else
			{
				$("#current_month_amount").val(current_month_amount);
				$("#admin_discount").val('');
				$("#admin_discount_amount").val('');

				$("#total_amount").val(total_amount);
				$("#final_amount").val(total_amount);

			   	$("#next_plan_amount").text(''); 
			   	$("#next_month_amount").val(''); 
			}
		   	

		});

		$("#admin_discount").change(function(){
			
			var admin_discount = $(this).val();

		   	if(admin_discount!=null)
		   	{
		   		/*alert(registration_amount);
		   		alert(current_month_amount);
		   		alert(feature_months_amount);
		   		alert(current_month_amount_discount);*/
		   		abd=parseInt(registration_amount)+parseInt(current_month_amount)+parseInt(feature_months_amount)-parseInt(current_month_amount_discount);
		   		//alert(abd);
		   		var admin_discount_amount = (abd*(admin_discount/100));
		   		final_amount = parseInt(registration_amount)+parseInt(current_month_amount)+parseInt(feature_months_amount)-(admin_discount_amount+current_month_amount_discount);
		   		$("#final_amount").val(final_amount);
		   		$("#admin_discount_amount").val(admin_discount_amount);
		   	}
		

		});

		    $("#enrollstudent").validate({
      rules: {

        class_id:"required",
       /* class_id: {
        	required: true,
        	remote:{
        		url: "<?=base_url('admin/checkstudentclass')?>",
        		type:"POST",
        		data:{
        			class_id:function(){
        				return $("input[name=class_id]").val();
        				},
        			member_id: member_id	
        			},
        	},
        	},*/
        plan_id: "required",
      	start_date:"required",
        current_month_amount:"required",
         "selected_batches[]":{
         	required: true
         }
        
        

      },
    });



	});
</script>