<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller 
{


	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model("mastertable_model");
		$this->load->model("categories_model");
		$this->load->model("users_model");
		$this->load->model("services_model");
		$this->load->model("category_slots_model");
		$this->load->model("user_address_model");
		$this->load->model("service_tax_model");
		$this->load->library('Uploaddata');
		$this->load->library("sms");
		

		
		
	}
	public function index()
	{
		$views = array('index');
 		$categories = $this->categories_model->get_categories_by_condition(array('status'=>1));
		
		$data = array("views"=>$views,"categories"=>$categories);//,"main_categories"=>$main_categories

		$this->load->view('template/template',$data);
	}

	public function getcategories()
	{
		$main_cat_id = $this->input->post('main_cat_id');
		$categories = $this->main_category_categories_model->get_categories($main_cat_id);

		if(!empty($categories))
		{
			$results['categories'] = $categories;
			$results['success'] = 1;
		}
		else
		{
			$results['success'] = 2;	
		}
		echo json_encode($results);
	}

	public function getservices()
	{
		
		$cat_id = $this->input->post('cat_id');
		$user_id = $this->session->userdata('user_id');
		$address = $this->user_address_model->getaddress($user_id);
		$tax_info = $this->service_tax_model->gettax();

		$services = $this->services_model->getservicesbycondition(array('cat_id'=>$cat_id));

		$category = $this->categories_model->get_category($cat_id);

		$data = array('cat_id'=>$cat_id,'services'=>$services,'category'=>$category, 'address'=>$address, 'service_tax'=>$tax_info['service_tax']);
		$this->load->view('getservices',$data);
			
	}

	public function getslots()
	{
		$cat_id = $this->input->post('cat_id');
		$selected_date = $this->input->post('selected_date');
		//$service_id = $this->input->post('service_id');
		$date =date("Y-m-d");
		if($date==$selected_date)
		{
			$slots = $this->category_slots_model->getslotsbytoday($cat_id);
			//echo $this->db->last_query();
		}else
		{
			$slots = $this->category_slots_model->getslots($cat_id);
		} 
		

		if(!empty($slots))
		{
			foreach ($slots as $key => $value) {
				$value['start_time'] = date("h:i A",strtotime($value['start_time']));
				$value['end_time'] = date("h:i A",strtotime($value['end_time']));
				$slots1[]=$value;
			}
			$result['status'] =1;
			$result['slots'] =$slots1;
		}else
		{
			$result['status'] =2;
		}
		echo json_encode($result);
		
			
	}


	public function checkmobile()
	{
		$this->form_validation->set_rules('mobile','mobile','trim|required');
		if($this->form_validation->run())
		{
			$mobile = $this->input->post('mobile');
			$result = $this->users_model->getuserinfo(array('mobile'=>$mobile));
			if(empty($result))
			{
 				echo json_encode(true);
			}
			else
			{
				echo json_encode(false);
			}
 			
 		

		}
	}

	public function sendotp()
	{
		$this->form_validation->set_rules('mobile','mobile','trim|required');
		if($this->form_validation->run())
		{
			$mobile = $this->input->post('mobile');
			$result = $this->users_model->getuserinfo(array('mobile'=>$mobile));
			if(empty($result))
			{
				$otp = rand(1000,9999);

 				$message = "FUDYZ otp has $otp";
 				$response = $this->sms->sendsms($mobile,$message);
 				$this->session->set_userdata('otp',$otp); 
 				$result['success'] =1;
			}
			else
			{
				$result['success'] =2;
			}
 			
 			echo json_encode($result);

		}
	}

    public function resendotp()
    {
		$this->form_validation->set_rules('mobile','mobile','trim|required');
		
		if($this->form_validation->run())
		{
			$mobile = $this->input->post('mobile');
			$otp = $this->session->userdata('otp');
			$message = "FUDYZ otp has $otp";
			$response = $this->sms->sendsms($mobile,$message);
			if($response)
			{
				echo 1;
			}else
			{
				echo 2;
			}

		}
		else
		{
			redirect("index/index");
		}

    }

    public function verifyotp()
    {
		$this->form_validation->set_rules('mobile','mobile','trim|required');
		$this->form_validation->set_rules('otp','otp','trim|required');

		if($this->form_validation->run())
		{
			$mobile = $this->input->post('mobile');
			$otp = $this->input->post('otp');
			if($otp==$this->session->userdata('otp'))
			{
				echo json_encode(true);
				//echo 1;
			}else
			{
				echo json_encode(false);
				//echo 2;
			}


		}
		else
		{
			redirect("index/index");
		}

    }

	public function saveuser()
	{
		//print_r($_POST);exit;
		$this->form_validation->set_rules('name','Username','trim|required');
		$this->form_validation->set_rules('password','Password','trim|required');
		$this->form_validation->set_rules('email','email','trim|required');
		$this->form_validation->set_rules('mobile','mobile','trim|required');

		if($this->form_validation->run())
		{
			$name = $this->input->post('name');
			$email = $this->input->post('email');
			$mobile = $this->input->post('mobile');
			$password = $this->input->post('password');
			//print_r($_POST);exit;
			$userDetails1 =array('username'=>$mobile,
								 'password' => md5($password),
 									'user_type'=>2
									);
			$response1 = $this->mastertable_model->save($userDetails1);

			$referral_code= substr(str_shuffle(md5(time())),0,8);

			$userDetails =array('name'=>$name,
							'mobile'=>$mobile,
							'email'=>$email,
							'user_id'=>$response1,
							'referral_code'=>$referral_code,
							//'referee_code'=>$referee_code,
							'created_date'=>date('Y-m-d H:i:s')
							);
			
			$response = $this->users_model->save($userDetails);
			if($response)
			{
				//$this->session->set_flashdata('message','User created successfully');
				echo 1;
				//redirect('index/index');

			}else
			{
				echo 2;
				//$this->session->set_flashdata('message',"user creation error");
			}

		}else
		{
			redirect('index/index');
		}
	}

	public function authentication()
    {
		$this->form_validation->set_rules('mobile','mobile','trim|required');
		$this->form_validation->set_rules('password','password','trim|required');

		if($this->form_validation->run())
		{
			$mobile = $this->input->post('mobile');
			$password = $this->input->post('password');
			$response = $this->mastertable_model->authentication($mobile,md5($password));

			if(!empty($response))
			{
				$userDetails = $this->users_model->getuserinfo(array('user_id'=>$response['id']));
				$userDetails['user_type'] =2;
				$this->session->set_userdata($userDetails);
				echo 1;

			}else
			{
				echo 2;
			}

		}
		else
		{
			echo 2;
		}

    }

    public function generatepassword()
    {
		$this->form_validation->set_rules('mobile','mobile','trim|required');
		

		if($this->form_validation->run())
		{
			$mobile = $this->input->post('mobile');
			$result = $this->users_model->getuserinfo(array('mobile'=>$mobile));
			if(!empty($result))
			{
				
				$otp = rand(100000,999999);
 				$message = "Your FUDYZ account new password has $otp";
 				$response = $this->sms->sendsms($mobile,$message);
 				$userDetails = array('password'=>md5($otp));
 				$response1 = $this->mastertable_model->update($userDetails,$result['user_id']);
				//$userDetails = $this->users_model->getuserinfo(array('user_id'=>$response['id']));
				echo 1;

			}else
			{
				echo 2;
			}

		}
		else
		{
			echo 2;
		}

    }

    
}
