<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users_model extends CI_Model {

	const TABLE_NAME = "users";
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function save($userDetails)
	{
		$this->db->insert(self::TABLE_NAME, $userDetails);
		return $this->db->insert_id();
	}

	public function getuser($condition_array)
	{
		$this->db->select("users.*,branches.branch_name");
		$this->db->join("branches","branches.id=users.branch_id");
		$this->db->where($condition_array);//id=$id or 
		$query = $this->db->get(self::TABLE_NAME);	
        return $query->row_array();
				 
	}
	
	public function getusers($status=null)
	{		
		$this->db->select("users.*,user_family_members.name,user_family_members.profile_pic,user_family_members.id as member_id");
		$this->db->join("user_family_members","user_family_members.user_id=users.id");
		if(!empty($status))
		{
			$this->db->where("users.status",$status);
		}

		$query = $this->db->get(self::TABLE_NAME);			
        return $query->result_array();			 
	}

	public function getusersonly($status=null)
	{		
		$this->db->select("users.*");
		//$this->db->join("user_family_members","user_family_members.user_id=users.id");
		if(!empty($status))
		{
			$this->db->where("users.status",$status);
		}

		$query = $this->db->get(self::TABLE_NAME);			
        return $query->result_array();			 
	}

	public function checkusermobile($username,$user_id=null)
	{
		
		//$this->db->select("id,username,user_type");
		$this->db->where('mobile', $username);
		if(!empty($user_id))
		{
			$this->db->where("id != $user_id");
		}
        
        $query = $this->db->get(self::TABLE_NAME);	
       	
        return $query->row_array();	
	}

	/*	public function getuser($id)
	{
		$this->db->where("user_id=$id");//id=$id or 
		$query = $this->db->get(self::TABLE_NAME);	
        return $query->row_array();
				 
	}

	public function getuserbycondition($mobile,$email)
	{
		$this->db->select("users.*,count(orders.id) as orders");
		$this->db->join("orders","orders.user_id=users.user_id","left");
		$this->db->where("mobile='$mobile' or email ='$email'");//id=$id or 
		$this->db->group_by("users.user_id");
		$query = $this->db->get(self::TABLE_NAME);	
        return $query->result_array();
				 
	}

	*/

	public function updatestatus($user_id)
	{
//		update users SET status = IF(status = 1, 2, 1) where upid=".$_REQUEST['user_id']
		
		$this->db->set('status', 'IF(status = 1, 2, 1)', FALSE);
        $this->db->where('user_id', $user_id); 
		return $this->db->update(self::TABLE_NAME);			 
	}
	

	public function update($userDetails, $product_id)
	{
		
		$this->db->where('user_id', $product_id);
		return $this->db->update(self::TABLE_NAME, $userDetails);			 
	}

	public function delete($product_id)
	{
		
		$this->db->where('user_id', $product_id);
		return $this->db->delete(self::TABLE_NAME);
		
	}
	
}
