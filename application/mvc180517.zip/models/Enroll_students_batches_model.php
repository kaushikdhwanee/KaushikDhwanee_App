<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Enroll_students_batches_model extends CI_Model {

	const TABLE_NAME = "enroll_students_batches";
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function save($userDetails)
	{
		return	$this->db->insert_batch(self::TABLE_NAME, $userDetails);
		 //$this->db->insert_id();
	}
	public function getbatchclasses($enroll_student_id)
	{	
		/*if(!empty($status))
		{*/
			$this->db->select("enroll_students_batches.*,batch_classes.type,batch_classes.start_time,batch_classes.end_time");
			$this->db->join("batch_classes","batch_classes.id=enroll_students_batches.batch_class_id");
			$this->db->where('enroll_student_id', $enroll_student_id);
			$this->db->order_by('type');
		/*}*/	
		$query = $this->db->get_where(self::TABLE_NAME);			
        return $query->result_array();			 
	}
	/*public function get_branches_by_condition($condition)
	{		
		$query = $this->db->get_where(self::TABLE_NAME,$condition);			
        return $query->result_array();			 
	}
	public function getbranch($category_id)
	{		
		$this->db->where('id', $category_id);
		$query = $this->db->get(self::TABLE_NAME);		
        return $query->row_array();
				 
	}

	public function update($userDetails, $category_id)
	{
		
		$this->db->where('id', $category_id);
		return $this->db->update(self::TABLE_NAME, $userDetails);				 
	}*/

	public function delete($category_id)
	{
		
		$this->db->where('id', $category_id);
		return $this->db->delete(self::TABLE_NAME);				 
	}
}
